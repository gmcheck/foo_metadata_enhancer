#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Data Source
Provides metadata scraping using AI models via existing ModelAdapter
"""

import json
import logging
from typing import Dict, Any, Optional, List

from data_sources.base import (
    DataSourceType,
    ReleaseInfo,
    DataSourceAdapter,
    QueryInput,
    Candidate,
)
from common.text_utils import clean_value
from prompts.composer import get_composer, _build_default_ai_scrape_prompt

logger = logging.getLogger(__name__)


class AIAdapter(DataSourceAdapter):
    """AI 数据源适配器
    
    对接现有 AI Provider 系统，支持多种 AI 模型：
    - OpenRouter
    - Zhipu (智谱AI)
    - Gemini (Google)
    - Ollama (本地)
    """
    
    # 向后兼容别名：模块加载时用默认 config 构建一次
    # 运行时使用 get_composer(self._config).build_ai_scrape_system_prompt() 获取动态 Prompt
    SCRAPE_SYSTEM_PROMPT = _build_default_ai_scrape_prompt()
    
    def __init__(self, config: Dict[str, Any]):
        """初始化 AI 适配器
        
        Args:
            config: 配置字典
        """
        super().__init__(config)
        
        data_sources_config = config.get("data_sources", {})
        ai_config = data_sources_config.get("ai", {})
        
        self._enabled = ai_config.get("enabled", True)
        self._model_adapter = None
        
        self._init_model_adapter()
    
    def _init_model_adapter(self) -> None:
        """初始化模型适配器，对接现有的 AI Provider 系统"""
        try:
            from ai.adapter import ModelAdapter
            self._model_adapter = ModelAdapter(self._config)
            logger.info(f"AIAdapter initialized with provider: {self._model_adapter.get_provider_info()}")
        except Exception as e:
            logger.error(f"Failed to initialize AIAdapter: {e}")
            self._model_adapter = None
    
    @property
    def source_type(self) -> DataSourceType:
        """数据源类型"""
        return DataSourceType.AI
    
    @property
    def is_enabled(self) -> bool:
        """是否启用"""
        return self._enabled and self._model_adapter is not None
    
    def search_candidates(self, query: QueryInput) -> List[Candidate]:
        """使用 AI 进行刮削并返回候选列表
        
        AI 适配器作为兜底数据源，通常返回单个候选结果。
        但为保持接口一致性，仍返回 List[Candidate]。
        
        Args:
            query: 查询输入（title, artist, album, duration）
        
        Returns:
            List[Candidate]: 候选列表（通常只包含一个候选）
        """
        logger.info(
            f"AIAdapter::search_candidates: BEGIN, "
            f"title='{query.title}', artist='{query.artist}', album='{query.album}', "
            f"duration={query.duration}"
        )

        if not self._model_adapter:
            logger.warning("AIAdapter::search_candidates: model_adapter is None, cannot call AI")
            return []

        messages = self._build_candidates_prompt(query)
        logger.info(
            f"AIAdapter::search_candidates: calling AI, "
            f"system_prompt_len={len(messages[0]['content']) if messages else 0}, "
            f"user_prompt_len={len(messages[1]['content']) if len(messages) > 1 else 0}"
        )

        try:
            result = self._model_adapter.analyze(messages)

            if not result.success:
                logger.warning(
                    f"AIAdapter::search_candidates: AI call FAILED, "
                    f"error={result.error}, model={getattr(result, 'model', 'unknown')}"
                )
                return []

            logger.info(
                f"AIAdapter::search_candidates: AI call OK, "
                f"model={result.model}, "
                f"tokens: total={result.tokens_used} prompt={result.prompt_tokens} "
                f"completion={result.completion_tokens} reasoning={result.reasoning_tokens}, "
                f"result_type={type(result.result).__name__}, "
                f"result_size={len(str(result.result)) if result.result else 0}"
            )

            candidate = self._parse_ai_result_to_candidate(result.result, result.model, query)

            if candidate:
                logger.info(
                    f"AIAdapter::search_candidates: parsed candidate, "
                    f"title='{candidate.title[:40]}', artist='{candidate.artist[:40]}', "
                    f"album='{candidate.album[:40]}'"
                )
                return [candidate]
            logger.warning("AIAdapter::search_candidates: parsed candidate is None")
            return []

        except Exception as e:
            logger.error(
                f"AIAdapter::search_candidates: EXCEPTION {type(e).__name__}: {e}",
                exc_info=True
            )
            return []
    
    def _build_candidates_prompt(self, query: QueryInput) -> List[Dict[str, str]]:
        """构建 AI 候选查询提示
        
        Args:
            query: 查询输入
        
        Returns:
            List[Dict]: 消息列表
        """
        user_content = f"""Song Information:
Title: {query.title}
Artist: {query.artist}
{f"Album: {query.album}" if query.album else ""}
{f"Duration: {query.duration} seconds" if query.duration else ""}

Please provide metadata with confidence scores.
Return JSON with each field containing 'value' and 'confidence' (0.0-1.0).
Only include fields you can confidently identify."""

        return [
            {"role": "system", "content": get_composer(self._config).build_ai_scrape_system_prompt()},
            {"role": "user", "content": user_content}
        ]
    
    def _parse_ai_result_to_candidate(self, result: Any,
                                       model: str,
                                       query: QueryInput) -> Optional[Candidate]:
        """将 AI 结果解析为候选对象

        Args:
            result: AI 返回的 JSON 结果（dict 或 list[dict]）
            model: 使用的模型名称
            query: 原始查询输入

        Returns:
            Optional[Candidate]: 候选对象
        """
        if not result:
            return None

        # AI 偶尔不遵守 schema 返回 list（如 [{...}]），取第一个 dict 元素
        if isinstance(result, list):
            result = next((x for x in result if isinstance(x, dict)), None)
            if result is None:
                return None
        elif not isinstance(result, dict):
            return None

        def get_field_value(field_name: str) -> str:
            field_data = result.get(field_name, {})
            if isinstance(field_data, dict):
                return clean_value(field_data.get("value", ""))
            return ""

        def get_field_confidence(field_name: str) -> float:
            field_data = result.get(field_name, {})
            if isinstance(field_data, dict):
                return field_data.get("confidence", 0.5)
            return 0.5
        
        title = get_field_value("title") or query.title
        artist = get_field_value("artist") or query.artist
        
        avg_confidence = 0.0
        field_count = 0
        for field_name in ["title", "artist", "album", "year", "composer", "lyricist", "label"]:
            if result.get(field_name):
                avg_confidence += get_field_confidence(field_name)
                field_count += 1
        
        if field_count > 0:
            avg_confidence = avg_confidence / field_count
        else:
            avg_confidence = 0.5
        
        candidate = Candidate(
            title=title,
            artist=artist,
            album=get_field_value("album"),
            year=get_field_value("year"),
            track_number=get_field_value("track_number"),
            disc_number=get_field_value("disc_number"),
            genre=get_field_value("genre"),
            composer=get_field_value("composer"),
            lyricist=get_field_value("lyricist"),
            label=get_field_value("label"),
            country=get_field_value("country"),
            catalog_number=get_field_value("catalog_number"),
            musicbrainz_id=get_field_value("musicbrainz_id"),
            source=DataSourceType.AI,
            confidence=min(avg_confidence, 0.85),
            match_score=avg_confidence,
            sources=[DataSourceType.AI],
            raw={"ai_result": result, "model": model}
        )
        
        return candidate
    
    def get_release_info(self, release_id: str) -> Optional[ReleaseInfo]:
        """获取发行信息
        
        AI 适配器不支持通过 release_id 获取发行信息
        
        Args:
            release_id: 发行 ID（对 AI 无意义）
        
        Returns:
            ReleaseInfo: None
        """
        logger.warning("AIAdapter does not support get_release_info")
        return None
    
    def switch_provider(self, provider_type: str) -> bool:
        """切换 AI 提供商
        
        Args:
            provider_type: 'openrouter', 'zhipu', 'gemini', 'ollama', 'deepseek'
        
        Returns:
            bool: 切换成功返回 True
        """
        if self._model_adapter:
            return self._model_adapter.switch_provider(provider_type)
        return False
    
    def get_available_providers(self):
        """获取可用的 AI Provider 实例列表（V1）。

        Returns:
            list: 每项为 {id, name, protocol, model}；无 runtime 时返回 []
        """
        try:
            from ai.provider_runtime import get_provider_runtime
            rt = get_provider_runtime()
            if rt is None:
                return []
            return [
                {
                    "id": p.get("id"),
                    "name": p.get("name"),
                    "protocol": p.get("protocol"),
                    "model": p.get("model"),
                }
                for p in rt.store.list_providers(include_disabled=False)
            ]
        except Exception:
            return []

    def get_provider_info(self) -> Dict[str, Any]:
        """获取当前提供商信息
        
        Returns:
            Dict: 提供商信息
        """
        if self._model_adapter:
            return self._model_adapter.get_provider_info()
        return {
            "provider": "none",
            "model": "none",
            "status": "not configured"
        }
